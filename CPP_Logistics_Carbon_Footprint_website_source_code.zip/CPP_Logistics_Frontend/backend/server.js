const express = require('express');
const cors = require('cors');
const path = require('path');
const { PORT } = require('./config/constants');
const shipmentRoutes = require('./routes/shipmentRoutes');
const routeRoutes = require('./routes/routeRoutes');
const errorHandler = require('./middleware/errorHandler');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static Frontend Delivery
app.use(express.static(path.join(__dirname, '../')));

// API Routes
app.use('/api/shipments', shipmentRoutes);
app.use('/api/routes', routeRoutes);

// Centralized Error Handling Middleware
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`===========================================`);
  console.log(`LOGIFLOW Carbon Engine Server Running`);
  console.log(`Port: http://localhost:${PORT}`);
  console.log(`Dashboard: http://localhost:${PORT}/dashboard.html`);
  console.log(`Shipments: http://localhost:${PORT}/index.html`);
  console.log(`===========================================`);
});