const express = require('express');
const router = express.Router();
const routeController = require('../controllers/routeController');

router.post('/optimize', routeController.optimizeRoute);

module.exports = router;