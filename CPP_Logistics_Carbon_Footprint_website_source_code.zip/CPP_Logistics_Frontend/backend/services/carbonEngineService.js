const { EMISSION_FACTORS } = require('../config/constants');

class CarbonEngineService {
  static calculateMetrics({ distance, weight, mode, alpha = 0.5, beta = 0.5 }) {
    const distNum = parseFloat(distance);
    const weightNum = parseFloat(weight);
    const alphaNum = parseFloat(alpha);
    const betaNum = parseFloat(beta);

    if (isNaN(distNum) || distNum <= 0) throw new Error('Invalid distance value provided.');
    if (isNaN(weightNum) || weightNum <= 0) throw new Error('Invalid weight value provided.');

    const transportMode = EMISSION_FACTORS[mode];
    if (!transportMode) throw new Error(`Unsupported transport mode: ${mode}`);

    // Transit time in hours = distance / speed
    const transitHours = distNum / transportMode.speed;

    // CO2 output in kg = distance (km) * weight (metric tons) * emission_factor
    const weightInTons = weightNum / 1000.0;
    const co2Emissions = distNum * weightInTons * transportMode.factor;

    // Combined Objective Cost: C = alpha * Time + beta * CO2
    const combinedCost = (alphaNum * transitHours) + (betaNum * co2Emissions);

    return {
      distanceKm: distNum,
      weightKg: weightNum,
      mode,
      transitHours: Number(transitHours.toFixed(2)),
      co2Kg: Number(co2Emissions.toFixed(2)),
      combinedCost: Number(combinedCost.toFixed(2)),
      parameters: { alpha: alphaNum, beta: betaNum }
    };
  }

  static evaluateAllModes({ distance, weight, alpha, beta }) {
    const modes = Object.keys(EMISSION_FACTORS);
    const results = {};

    modes.forEach(mode => {
      results[mode] = this.calculateMetrics({ distance, weight, mode, alpha, beta });
    });

    return results;
  }
}

module.exports = CarbonEngineService;