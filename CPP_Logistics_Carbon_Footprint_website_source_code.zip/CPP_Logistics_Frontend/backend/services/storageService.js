const fs = require('fs').promises;
const path = require('path');

const shipmentsPath = path.join(__dirname, '../data/shipments.json');

class StorageService {
  static async readShipments() {
    try {
      const data = await fs.readFile(shipmentsPath, 'utf8');
      return JSON.parse(data || '[]');
    } catch (err) {
      if (err.code === 'ENOENT') {
        await this.writeShipments([]);
        return [];
      }
      throw new Error(`Failed to read dataset: ${err.message}`);
    }
  }

  static async writeShipments(data) {
    try {
      await fs.writeFile(shipmentsPath, JSON.stringify(data, null, 2), 'utf8');
    } catch (err) {
      throw new Error(`Failed to update dataset: ${err.message}`);
    }
  }
}

module.exports = StorageService;